import React from 'react';
import { 
  CCol,
  CRow,  
} from '@coreui/react'
import Chatcarousel from './Chatcarousel'
import StarIcon from '@material-ui/icons/Star';
import LocationOnIcon from '@material-ui/icons/LocationOn';
import 'react-date-range/dist/styles.css'; 
import 'react-date-range/dist/theme/default.css';
import WareHouseInfo from "./WareHouseInfo"
import WarehouseData from "./WarehouseData"
import Reviewinfo from "./Reviewinfo"
import Reviewdata from "./Reviewdata"

var Reviewcount = [...Reviewdata]
console.log(WarehouseData.key)

const Reviews = ()=>{   
    return(
        <>
        {WarehouseData.map((val)=>{           
            return(
          <WareHouseInfo
            key={val.key}
            Wtital= {val.Wtital}
            Wrank= {val.Wrank}
            Wrating= {val.Wrating}
            Wreview= {val.Wreview}            
            Wdiscription= {val.Wdiscription}
            Wregion= {val.Wregion}
            Wcommune= {val.Wcommune}
            Waddress= {val.Waddress}
            Wfeatureservices= {val.Wfeatureservices}
            Wlink= {val.Wlink}
            Wpromotionaltax= {val.Wpromotionaltax} 

           />
           );
        })}
        
        <CRow>
            <CCol lg="12" sm="12">
               <h4>Reviews ({Reviewcount.length})</h4> 
            </CCol>
        </CRow>  
        {Reviewdata.map((val)=>{            
        return(
            <Reviewinfo
              Rusername={val.Rusername}
              Rrating={val.Rrating}
              Rdiscription={val.Rdiscription}
             />
        );
        })}
        </>
    ); 
}
export default Reviews;