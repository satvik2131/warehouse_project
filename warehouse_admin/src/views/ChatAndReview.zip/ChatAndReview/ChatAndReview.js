import React, { useState } from 'react';
import { 
  CCol,
  CRow,  
} from '@coreui/react'
import 'react-date-range/dist/styles.css'; 
import 'react-date-range/dist/theme/default.css'; 
import WareHouseInfo from "./WareHouseInfo";
import WarehouseData from "./WarehouseData";




const ChatAndReview = ()=>{  

  const showcard =(id)=>{  
    console.log(id)   
  
  }
  
    return(        
        <>   
       {WarehouseData.map((val,index)=>{           
        return(
        <WareHouseInfo  
        key={index}       
        id={index}
        Wtital= {val.Wtital}
        Wrank= {val.Wrank}
        Wrating= {val.Wrating}
        Wreview= {val.Wreview}
        Wpendingreview= {val.Wpendingreview}
        Wdiscription= {val.Wdiscription}
        Wregion= {val.Wregion}
        Wcommune= {val.Wcommune}
        Waddress= {val.Waddress}
        Wfeatureservices= {val.Wfeatureservices}
        Wlink= {val.Wlink}
        Wpromotionaltax= {val.Wpromotionaltax}
        onSelect={showcard}        
        />
    );

       })} 
       </>   
    )

}
export default ChatAndReview;